import React, { useState, useCallback, useRef, useMemo, useEffect } from 'react';
import { Card, Button, Switch, Progress, Message, Space, Typography, Spin } from '@arco-design/web-react';
import { IconUpload } from '@arco-design/web-react/icon';
import { BitmapProvider, useBitmap } from './context';
import { BitmapCanvasAdapter } from './components/BitmapCanvasAdapter';
import { BitmapEngine } from './core';
import type { BitmapEngineRef } from './core';
import { BitmapDataTable } from './components/BitmapDataTable';
import { CellInfoPopup } from './components/CellInfoPopup';
import { ColorConfigPanel } from './components/ColorConfigPanel';
import { parseFile, validateFile, mergeBitmapData } from './parsers';
import { CellData } from './types';
import { createColorMap } from './utils/colorMap';

const { Title, Text } = Typography;

const BitmapVisualizationInner: React.FC = () => {
	const { state, dispatch } = useBitmap();
	const [showPopup, setShowPopup] = useState(false);
	const [selectedCellData, setSelectedCellData] = useState<CellData | null>(null);
	const [uploadProgress, setUploadProgress] = useState(0);
	const [isUploading, setIsUploading] = useState(false);
	const [useNewEngine, setUseNewEngine] = useState(true);
	const fileInputRef = useRef<HTMLInputElement>(null);
	const engineRef = useRef<BitmapEngineRef | null>(null);

	const handleCellClickWrapper = useCallback((cellInfo: { data: CellData; rowIndex: number; colIndex: number }) => {
		setSelectedCellData(cellInfo.data);
		setShowPopup(true);
		dispatch({ type: 'SELECT_CELL', payload: { bl: cellInfo.rowIndex, wl: cellInfo.colIndex } });
	}, [dispatch]);

	const handleEngineCellClick = useCallback((ctx: { cell: CellData | null; row: number; col: number }) => {
		if (!ctx.cell) {
			return;
		}
		setSelectedCellData(ctx.cell);
		setShowPopup(true);
		dispatch({ type: 'SELECT_CELL', payload: { bl: ctx.row, wl: ctx.col } });
	}, [dispatch]);

	const handleFileUpload = useCallback(async (file: File) => {
		const validation = validateFile(file);
		if (!validation.valid) {
			Message.error(validation.error || '文件验证失败');
			return;
		}

		if (validation.warning) {
			Message.warning(validation.warning);
		}

		setIsUploading(true);
		setUploadProgress(0);

		try {
			const result = await parseFile(file, {
				onProgress: (progress) => setUploadProgress(progress),
			});

			if (!result.success || !result.data) {
				Message.error(result.error || '解析失败');
				return;
			}

			if (state.dataMode === 'merge' && state.data) {
				const mergedData = mergeBitmapData(state.data, result.data);
				dispatch({ type: 'SET_DATA', payload: mergedData });
				Message.success(`数据已合并，共 ${mergedData.cells.length} 个单元格`);
			} else {
				dispatch({ type: 'SET_DATA', payload: result.data });
				Message.success(`加载成功，共 ${result.data.cells.length} 个单元格`);
			}
		} catch (error) {
			Message.error('文件解析失败');
			console.error(error);
		} finally {
			setIsUploading(false);
			setUploadProgress(0);
		}
	}, [state.dataMode, state.data, dispatch]);

	const handleDataModeChange = useCallback((checked: boolean) => {
		dispatch({ type: 'SET_DATA_MODE', payload: checked ? 'merge' : 'overwrite' });
	}, [dispatch]);

	const handleDragOver = useCallback((e: React.DragEvent) => {
		e.preventDefault();
		e.stopPropagation();
	}, []);

	const handleDrop = useCallback((e: React.DragEvent) => {
		e.preventDefault();
		e.stopPropagation();

		const files = e.dataTransfer.files;
		if (files.length > 0) {
			handleFileUpload(files[0]);
		}
	}, [handleFileUpload]);

	const stats = useMemo(() => {
		if (!state.data) return null;

		const total = state.data.cells.length;
		const passCount = state.data.cells.filter(c => c.status === 'pass').length;
		const failCount = state.data.cells.filter(c => c.status === 'fail').length;

		return { total, passCount, failCount };
	}, [state.data]);

const matrixData = useMemo(() => {
  if (!state.data) {
    return null;
  }
  // 转置矩阵：X轴对应BL(128)，Y轴对应WL(1024)
  // 原来的 rows=128, cols=1024，交换后 rows=1024, cols=128
  return {
    rows: state.data.cols, // Y轴：1024 (WL)
    cols: state.data.rows, // X轴：128 (BL)
    cells: state.data.cells,
    getRowIndex: (cell: CellData) => cell.wl, // Y轴坐标由 WL 决定
    getColIndex: (cell: CellData) => cell.bl, // X轴坐标由 BL 决定
  };
}, [state.data]);

	const colorMap = useMemo(() => createColorMap(state.colorConfig), [state.colorConfig]);

	const getCellColor = useCallback((cell: CellData | null): string => {
		if (!cell) {
			return '#ffffff';
		}
		return colorMap.getColorByCell(cell);
	}, [colorMap]);

	useEffect(() => {
		if (!useNewEngine || !state.viewState.selectedCell) {
			return;
		}

		engineRef.current?.zoomToCell(
			state.viewState.selectedCell.bl,
			state.viewState.selectedCell.wl
		);
	}, [useNewEngine, state.viewState.selectedCell]);

	return (
		<div className="bitmap-visualization">
			<div className="bitmap-header">
				<Title heading={5}>RRAM 测试结果可视化</Title>
				<Space>
					<Text>合并模式</Text>
					<Switch
						checked={state.dataMode === 'merge'}
						onChange={handleDataModeChange}
					/>
					<Text>新引擎</Text>
					<Switch
						checked={useNewEngine}
						onChange={(checked) => setUseNewEngine(checked)}
					/>
				</Space>
			</div>

			<div className="bitmap-toolbar">
				<input
					ref={fileInputRef}
					type="file"
					accept=".json,.txt,.csv,.log,.dat,.stdf,.std"
					style={{ display: 'none' }}
					onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
				/>
				<Button
					type="primary"
					icon={<IconUpload />}
					onClick={() => fileInputRef.current?.click()}
					loading={isUploading}
				>
					上传文件
				</Button>
				{stats && (
					<Space>
						<Text type="secondary">总计: {stats.total}</Text>
						<Text type="success">Pass: {stats.passCount}</Text>
						<Text type="error">Fail: {stats.failCount}</Text>
					</Space>
				)}
			</div>

			{isUploading && (
				<Progress
					percent={uploadProgress}
					style={{ margin: '8px 0' }}
				/>
			)}

			<div className="bitmap-content">
				<div
					className="bitmap-canvas-wrapper"
					onDragOver={handleDragOver}
					onDrop={handleDrop}
				>
					{isUploading && <Spin tip="解析中..." />}
					{!isUploading && useNewEngine && matrixData && (
						<BitmapEngine
							ref={engineRef}
							data={matrixData}
							minCellSize={8}
							maxCellSize={32}
							defaultCellSize={12}
							selectedCell={
								state.viewState.selectedCell
									? { row: state.viewState.selectedCell.bl, col: state.viewState.selectedCell.wl }
									: null
							}
							onSelectedCellChange={(cell) => {
								dispatch({
									type: 'SELECT_CELL',
									payload: cell ? { bl: cell.row, wl: cell.col } : null,
								});
							}}
							getCellColor={getCellColor}
							onCellClick={handleEngineCellClick}
						/>
					)}
					{!isUploading && (!useNewEngine || !matrixData) && (
						<BitmapCanvasAdapter onCellClick={handleCellClickWrapper} />
					)}
				</div>

				<div className="bitmap-sidebar">
					<Card title="颜色配置" size="small" style={{ marginBottom: 8 }}>
						<ColorConfigPanel
							config={state.colorConfig}
							onChange={(config) => dispatch({ type: 'SET_COLOR_CONFIG', payload: config })}
						/>
					</Card>

					<Card title="数据表格" size="small">
						<BitmapDataTable />
					</Card>
				</div>
			</div>

			<CellInfoPopup
				visible={showPopup}
				cell={selectedCellData}
				onClose={() => setShowPopup(false)}
			/>
		</div>
	);
};

const BitmapVisualization: React.FC = () => {
	return (
		<BitmapProvider>
			<BitmapVisualizationInner />
		</BitmapProvider>
	);
};

export default BitmapVisualization;	
