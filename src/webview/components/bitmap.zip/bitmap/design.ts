/**
 * BitmapEngine 交互设计规范
 * 
 * 本文件记录 BitmapEngine 组件的核心交互设计思想
 */

export const InteractionDesign = {
  /**
   * 缩放交互设计
   * 
   * 设计原则：
   * 1. 缩放范围：限制在 0.8 ~ 1.4 之间
   *    - 最小 0.8：保证缩放后格子仍然可见，不会出现过于密集的情况
   *    - 最大 1.4：限制最大放大倍数，避免过度放大导致性能问题
   * 
   * 2. 缩放步长：0.1
   *    - 每次放大缩小增减 0.1，提供精细的缩放控制
   *    - 从 1.0 开始，缩小到 0.8 需要两次，放大到 1.4 需要四次
   * 
   * 3. 触发方式：
   *    - Ctrl + 滚轮：缩放操作（必须按住 Ctrl 键）
   *    - 普通滚轮：保持原有的滚动浏览功能（不缩放）
   *    - 这种设计避免误操作，用户明确意图后才触发缩放
   * 
   * 4. 缩放原点：
   *    - 以鼠标指针位置为中心进行缩放
   *    - 缩放后自动调整 scroll 位置，保持鼠标指向的内容在可视区域内
   */
  zoom: {
    min: 0.8,
    max: 1.4,
    step: 0.1,
    default: 1.0,
    trigger: 'Ctrl + Wheel',
    origin: 'mouse-pointer',
  },

  /**
   * 平移交互设计
   * 
   * 设计原则：
   * 1. 触发方式：鼠标拖拽（按住左键拖动）
 *    - 不依赖 Ctrl 键，直接拖拽即可平移
   *    - 拖拽时鼠标变为 grabbing 状态
   * 
   * 2. 平移边界：
   *    - 限制在内容区域内，不能拖出空白区域
   *    - 使用 scrollLeft/scrollTop 控制位置
   * 
   * 3. 性能优化：
   *    - 平移时不重新渲染，只更新 scroll 位置
   *    - 使用 RAF (requestAnimationFrame) 更新视图状态
   */
  pan: {
    trigger: 'Mouse Drag (Left Button)',
    cursor: 'grabbing',
    boundary: 'content-only',
    optimization: ' RAF + scroll update',
  },

  /**
   * 工具栏设计
   * 
   * 设计原则：
   * 1. 位置：绝对定位在 X 轴右上角
   *    - top: 50%, right: 8px
   *    - transform: translateY(-50%) 垂直居中
   *    - zIndex: 10 确保在最上层
   * 
   * 2. 样式：
 *    - 半透明背景：rgba(245, 245, 245, 0.95)
   *    - 边框：1px solid #ddd
   *    - 圆角：4px
   *    - 内边距：4px 8px
   * 
   * 3. 按钮布局：
   *    - 使用 flex 布局，gap: 4px
   *    - 按钮类型：secondary，size: small
   *    - 使用 Tooltip 显示功能提示
   * 
   * 4. 按钮功能：
   *    - 放大 (+0.1)：currentZoom + 0.1
   *    - 缩小 (-0.1)：currentZoom - 0.1
   *    - 还原 (1:1)：重置为 1.0，并滚动到 (0, 0)
   *    - 适应屏幕：计算最佳缩放比例使内容填满视口
   * 
   * 5. 缩放比例显示：
   *    - 显示在按钮组右侧
   *    - 格式："1.0x"
   *    - 固定宽度 45px，居中对齐
   */
  toolbar: {
    position: 'absolute top-right',
    background: 'rgba(245, 245, 245, 0.95)',
    border: '1px solid #ddd',
    borderRadius: '4px',
    buttons: ['zoomIn', 'zoomOut', 'reset', 'fitScreen'],
    zoomDisplay: {
      format: '1.0x',
      width: '45px',
      align: 'center',
    },
  },

  /**
   * 状态管理设计
   * 
   * 设计原则：
   * 1. 视图状态：
   *    interface ViewState {
   *      zoom: number;      // 缩放比例
   *      offsetX: number;   // X轴偏移（scrollLeft）
   *      offsetY: number;   // Y轴偏移（scrollTop）
   *    }
   * 
   * 2. 状态更新：
   *    - 通过 setViewState 统一更新
   *    - 支持受控和非受控两种模式
   *    - 外部可通过 ref 调用方法修改状态
   * 
   * 3. 性能优化：
   *    - 使用 useRef 保存最新状态，避免闭包问题
   *    - 使用 requestAnimationFrame 批量更新
   *    - 虚拟化渲染：仅渲染可视区域
   */
  state: {
    viewState: {
      zoom: 'number (0.8 ~ 1.4)',
      offsetX: 'number (scroll position)',
      offsetY: 'number (scroll position)',
    },
    updateMethod: 'setViewState',
    optimization: ['useRef', 'RAF', 'virtualization'],
  },

  /**
   * 性能优化策略
   * 
   * 1. 对象池复用：
   *    - 复用 Konva.Rect 对象，避免频繁创建销毁
   *    - 不可见区域的对象设为 visible: false 而非销毁
   * 
   * 2. RAF 节流：
   *    - 使用 requestAnimationFrame 批量处理渲染
   *    - 避免短时间内多次重绘
   * 
   * 3. 虚拟化渲染：
   *    - 仅渲染可视区域内的格子
   *    - Overscan 预渲染：多渲染 2 屏内容
   * 
   * 4. 状态引用：
   *    - 使用 ref 保存最新状态，避免闭包陷阱
   *    - zoomRef, viewStateRef, dataRef 等
   */
  performance: {
    objectPool: 'Reuse Konva.Rect objects',
    rafThrottling: 'Batch render with RAF',
    virtualization: 'Render visible area only (overscan: 2x)',
    refs: 'Use refs to avoid closure issues',
  },

  /**
   * 坐标轴设计
   * 
   * 1. X轴（顶部）：
   *    - 高度：36px（包含刻度文字和按钮组空间）
   *    - 刻度文字：垂直居中
   *    - 工具栏：绝对定位在右上角
   * 
   * 2. Y轴（左侧）：
   *    - 宽度：50px
   *    - 刻度文字：水平左对齐
   *    - 固定不滚动
   * 
   * 3. 刻度自适应：
   *    - 根据 zoom 级别自动调整刻度间隔
   *    - zoom >= 1.0：显示更多刻度
   *    - zoom < 1.0：减少刻度密度
   */
  axis: {
    x: {
      height: '36px',
      position: 'top',
      toolbar: 'absolute top-right',
    },
    y: {
      width: '50px',
      position: 'left',
      fixed: true,
    },
    tickAdaptive: true,
  },
} as const;

/**
 * 使用示例
 * 
 * ```tsx
 * import { BitmapEngine } from './core/BitmapEngine';
 * 
 * function App() {
 *   const engineRef = useRef<BitmapEngineRef>(null);
 *   
 *   return (
 *     <BitmapEngine
 *       ref={engineRef}
 *       data={matrixData}
 *       minCellSize={8}
 *       maxCellSize={32}
 *       defaultCellSize={12}
 *       axisConfig={{
 *         showX: true,
 *         showY: true,
 *         showToolbar: true, // 显示工具栏
 *       }}
 *     />
 *   );
 * }
 * ```
 */

export default InteractionDesign;
