# Bitmap 可视化组件设计方案 - 混合架构（OOP + Hooks）

## 文档信息

- **方案名称**: 混合架构（OOP 内核 + Hooks 外壳）
- **推荐等级**: ★★★★☆ (备选方案)
- **适用场景**: 追求极致性能、需要脱离 React 复用渲染内核、团队 OOP 背景强
- **创建日期**: 2026-04-21

---

## 1. 架构概述

### 1.1 设计哲学

**"内核 OOP，外壳 FP"** - 底层 Konva 渲染逻辑用面向对象封装，上层 React 状态管理用函数式 Hooks。

```
┌─────────────────────────────────────────────────────────┐
│ React 外壳层 (FP - Hooks)                                │
│  ├─ useBitmapEngine.ts   (协调生命周期)                 │
│  ├─ MatrixBitmap.tsx     (React 组件)                   │
│  └─ FlowBitmap.tsx       (React 组件)                   │
├─────────────────────────────────────────────────────────┤
│ 内核抽象层 (OOP - 抽象类)                                │
│  ├─ BaseBitmapRenderer   (抽象基类)                    │
│  ├─ MatrixRenderer.ts    (规范二维实现)                │
│  └─ FlowRenderer.ts      (流模式实现)                  │
├─────────────────────────────────────────────────────────┤
│ 基础设施层                                              │
│  ├─ Konva 实例管理                                      │
│  ├─ 对象池管理                                         │
│  └─ 事件系统                                           │
└─────────────────────────────────────────────────────────┘
```

### 1.2 核心设计原则

- **职责分离**: 渲染（OOP）与 UI 状态（Hooks）解耦
- **性能优先**: OOP 内核直接操作 Konva，无 React 渲染开销
- **可测试性**: OOP 内核可脱离 React 单独测试
- **可复用性**: 内核可被非 React 环境使用（如 Web Worker、原生应用）

---

## 2. 内核层设计（OOP）

### 2.1 BaseBitmapRenderer - 抽象基类

```typescript
// core/renderers/BaseBitmapRenderer.ts
export abstract class BaseBitmapRenderer<T> {
  protected stage: Konva.Stage | null = null;
  protected layer: Konva.Layer | null = null;
  protected cellPool: Map<string, Konva.Rect> = new Map();
  protected visibleKeys: Set<string> = new Set();
  
  // 抽象方法：子类必须实现
  abstract calculateLayout(data: T[]): LayoutConfig;
  abstract getYAxisLabel(row: number): string;
  abstract getCellPosition(dataIndex: number): CellPosition;
  abstract getDataIndex(row: number, col: number): number;
  
  // 具体方法：共用的高性能渲染逻辑
  protected renderVisibleArea(
    layout: LayoutConfig,
    viewport: Viewport,
    data: T[],
    getColor: (cell: T) => string
  ): void {
    // 虚拟化渲染逻辑（共用）
    const { startRow, endRow, startCol, endCol } = this.calculateVisibleRange(
      layout, viewport
    );
    
    // 复用对象池中的 Rect
    for (let row = startRow; row < endRow; row++) {
      for (let col = startCol; col < endCol; col++) {
        const key = `${row}-${col}`;
        const dataIndex = this.getDataIndex(row, col);
        const cell = data[dataIndex];
        
        let rect = this.cellPool.get(key);
        if (!rect) {
          rect = this.createRect();
          this.cellPool.set(key, rect);
        }
        
        this.updateRect(rect, row, col, layout, getColor(cell));
        this.visibleKeys.add(key);
      }
    }
    
    // 隐藏不可见格子
    this.hideInvisibleCells();
    this.layer?.batchDraw();
  }
  
  // 缩放控制
  setZoom(zoom: number): void {
    this.stage?.scaleX(zoom);
    this.stage?.scaleY(zoom);
  }
  
  // 选中格子
  selectCell(row: number, col: number): SelectionInfo {
    // 子类可覆盖
    return {
      row,
      col,
      dataIndex: this.getDataIndex(row, col),
    };
  }
  
  // 销毁
  destroy(): void {
    this.cellPool.forEach(rect => rect.destroy());
    this.cellPool.clear();
    this.stage?.destroy();
  }
  
  // 私有方法
  private createRect(): Konva.Rect {
    return new Konva.Rect({ listening: false });
  }
  
  private hideInvisibleCells(): void {
    this.cellPool.forEach((rect, key) => {
      if (!this.visibleKeys.has(key)) {
        rect.visible(false);
      }
    });
    this.visibleKeys.clear();
  }
}
```

### 2.2 MatrixRenderer - 规范二维实现

```typescript
// core/renderers/MatrixRenderer.ts
export class MatrixRenderer extends BaseBitmapRenderer<CellData> {
  private readonly fixedRows = 128;
  private readonly fixedCols = 1024;
  private cellSize: number = 12;
  
  calculateLayout(data: CellData[]): LayoutConfig {
    return {
      rows: this.fixedRows,
      cols: this.fixedCols,
      totalWidth: this.fixedCols * this.cellSize,
      totalHeight: this.fixedRows * this.cellSize,
    };
  }
  
  getYAxisLabel(row: number): string {
    // Y轴刻度：0, 1, 2...
    return row.toString();
  }
  
  getCellPosition(dataIndex: number): CellPosition {
    // 根据 bl/wl 定位
    const cell = data[dataIndex];
    return {
      row: cell.bl,
      col: cell.wl,
    };
  }
  
  getDataIndex(row: number, col: number): number {
    // 在原始数据中找到对应索引
    return row * this.fixedCols + col;
  }
  
  selectCell(row: number, col: number): SelectionInfo {
    const base = super.selectCell(row, col);
    return {
      ...base,
      mode: 'matrix',
      display: `${row}, ${col}`,
    };
  }
}
```

### 2.3 FlowRenderer - 流模式实现（核心差异）

```typescript
// core/renderers/FlowRenderer.ts
export class FlowRenderer extends BaseBitmapRenderer<CellData> {
  private cellsPerRow: number = 42;
  private cellSize: number = 12;
  private containerWidth: number = 800;
  private zoom: number = 1;
  
  // 关键差异：动态计算列数
  setContainerWidth(width: number): void {
    this.containerWidth = width;
    this.recalculateLayout();
  }
  
  setZoom(zoom: number): void {
    this.zoom = zoom;
    this.recalculateLayout();
    super.setZoom(zoom);
  }
  
  private recalculateLayout(): void {
    const actualCellSize = this.cellSize * this.zoom;
    this.cellsPerRow = Math.max(1, Math.floor(this.containerWidth / actualCellSize));
  }
  
  calculateLayout(data: CellData[]): LayoutConfig {
    const totalRows = Math.ceil(data.length / this.cellsPerRow);
    return {
      rows: totalRows,
      cols: this.cellsPerRow,
      totalWidth: this.cellsPerRow * this.cellSize * this.zoom,
      totalHeight: totalRows * this.cellSize * this.zoom,
    };
  }
  
  getYAxisLabel(row: number): string {
    // 关键差异：Y轴显示数据起始索引 (0, 42, 84...)
    return (row * this.cellsPerRow).toString();
  }
  
  getCellPosition(dataIndex: number): CellPosition {
    // 根据数据索引计算行列
    return {
      row: Math.floor(dataIndex / this.cellsPerRow),
      col: dataIndex % this.cellsPerRow,
    };
  }
  
  getDataIndex(row: number, col: number): number {
    return row * this.cellsPerRow + col;
  }
  
  selectCell(row: number, col: number): SelectionInfo {
    const dataIndex = this.getDataIndex(row, col);
    return {
      mode: 'flow',
      row,
      col,
      dataIndex,
      display: `${row * this.cellsPerRow}, ${col}`, // "42, 8"
    };
  }
}
```

### 2.4 内核单元测试

```typescript
// core/renderers/__tests__/FlowRenderer.test.ts
describe('FlowRenderer', () => {
  let renderer: FlowRenderer;
  
  beforeEach(() => {
    renderer = new FlowRenderer();
  });
  
  afterEach(() => {
    renderer.destroy();
  });
  
  it('calculates correct cells per row based on container width', () => {
    renderer.setContainerWidth(800);
    renderer.setZoom(1);
    
    const layout = renderer.calculateLayout(mockData);
    
    // 800 / 12 = 66.66，取整为 66
    expect(layout.cols).toBe(66);
    expect(layout.rows).toBe(Math.ceil(mockData.length / 66));
  });
  
  it('recalculates when zoom changes', () => {
    renderer.setContainerWidth(800);
    renderer.setZoom(1);   // cellSize = 12
    renderer.setZoom(1.2); // cellSize = 14.4
    
    const layout = renderer.calculateLayout(mockData);
    
    // 800 / 14.4 = 55.55，取整为 55
    expect(layout.cols).toBe(55);
  });
  
  it('maps data index to position correctly', () => {
    renderer.setContainerWidth(800);
    renderer.setZoom(1);
    
    // 第 50 个数据
    expect(renderer.getCellPosition(50)).toEqual({
      row: 0,
      col: 50,
    });
    
    // 第 70 个数据（超过第一行）
    expect(renderer.getCellPosition(70)).toEqual({
      row: 1,
      col: 4, // 70 - 66 = 4
    });
  });
  
  it('generates correct Y axis labels', () => {
    renderer.setContainerWidth(800);
    renderer.setZoom(1);
    
    expect(renderer.getYAxisLabel(0)).toBe('0');
    expect(renderer.getYAxisLabel(1)).toBe('66');
    expect(renderer.getYAxisLabel(2)).toBe('132');
  });
  
  it('returns correct selection info', () => {
    renderer.setContainerWidth(800);
    renderer.setZoom(1);
    
    const selection = renderer.selectCell(1, 8);
    
    expect(selection.display).toBe('66, 8');
    expect(selection.dataIndex).toBe(74); // 66 + 8
  });
});
```

---

## 3. 外壳层设计（Hooks）

### 3.1 useBitmapEngine - 协调 Hooks

```typescript
// hooks/useBitmapEngine.ts
export function useBitmapEngine<T>(
  RendererClass: new () => BaseBitmapRenderer<T>,
  data: T[],
  options: BitmapEngineOptions
) {
  // 持有 OOP 内核实例
  const rendererRef = useRef<BaseBitmapRenderer<T>>(null);
  
  // React 状态（UI 层）
  const [zoom, setZoom] = useState(1);
  const [selectedCell, setSelectedCell] = useState<CellCoord | null>(null);
  const [containerWidth, setContainerWidth] = useState(800);
  
  // 初始化 OOP 内核
  useEffect(() => {
    rendererRef.current = new RendererClass();
    
    // 流模式特有：设置容器宽度
    if (rendererRef.current instanceof FlowRenderer) {
      rendererRef.current.setContainerWidth(containerWidth);
    }
    
    return () => {
      rendererRef.current?.destroy();
      rendererRef.current = null;
    };
  }, [RendererClass]);
  
  // 数据变化时重新计算布局
  useEffect(() => {
    if (!rendererRef.current) return;
    
    const layout = rendererRef.current.calculateLayout(data);
    // 更新 Konva Stage 尺寸
    // ...
  }, [data]);
  
  // 缩放控制
  const zoomIn = useCallback(() => {
    const next = Math.min(zoom + 0.1, MAX_ZOOM);
    setZoom(next);
    rendererRef.current?.setZoom(next);
  }, [zoom]);
  
  const zoomOut = useCallback(() => {
    const next = Math.max(zoom - 0.1, MIN_ZOOM);
    setZoom(next);
    rendererRef.current?.setZoom(next);
  }, [zoom]);
  
  // 选中处理
  const handleCellClick = useCallback((row: number, col: number) => {
    const selection = rendererRef.current?.selectCell(row, col);
    setSelectedCell({ row, col });
    return selection;
  }, []);
  
  // 流模式特有：监听容器宽度
  useEffect(() => {
    if (!(rendererRef.current instanceof FlowRenderer)) return;
    
    const observer = new ResizeObserver((entries) => {
      const width = entries[0].contentRect.width;
      setContainerWidth(width);
      rendererRef.current?.setContainerWidth(width);
    });
    
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);
  
  return {
    zoom,
    zoomIn,
    zoomOut,
    selectedCell,
    handleCellClick,
    containerRef,
  };
}
```

### 3.2 FlowBitmap 组件

```typescript
// components/FlowBitmap.tsx
export function FlowBitmap({ data, ...props }) {
  const {
    zoom,
    zoomIn,
    zoomOut,
    selectedCell,
    handleCellClick,
    containerRef,
  } = useBitmapEngine(FlowRenderer, data, {
    minZoom: 0.8,
    maxZoom: 1.4,
  });
  
  return (
    <div className="flow-bitmap" ref={containerRef}>
      <Toolbar
        onZoomIn={zoomIn}
        onZoomOut={zoomOut}
        onReset={() => {/* */}}
        zoom={zoom}
      />
      
      <div className="canvas-container" style={{ overflowX: 'hidden' }}>
        {/* Konva Stage 挂载点 */}
        <div ref={stageContainerRef} />
      </div>
      
      {/* Y轴刻度：通过内核计算 */}
      <YAxis
        getLabel={(row) => {
          return (row * 42).toString(); // 实际应该是动态计算
        }}
      />
    </div>
  );
}
```

---

## 4. 架构对比

### 4.1 两种方案的差异

| 维度 | Context + Hooks (plan.md) | 混合架构 OOP+Hooks (本方案) |
|------|---------------------------|----------------------------|
| **渲染控制** | React Hooks 管理 | OOP 内核直接控制 |
| **状态同步** | React State -> Konva | OOP 内核内部状态 |
| **性能** | 优秀 | **更优秀**（无 React 渲染开销） |
| **可测试性** | 测试 Hooks | **测试 OOP 类**（更简单） |
| **可复用性** | 依赖 React | **可脱离 React** |
| **代码量** | 较少 | 较多（多一层抽象） |
| **维护成本** | 低 | **中**（两层架构） |
| **学习曲线** | 平缓 | 较陡（需理解 OOP） |

### 4.2 混合架构的优势

1. **极致性能**
   - OOP 内核直接操作 Konva，无 React 渲染周期
   - 缩放/平移不触发 React 重渲染
   - 20万数据下依然 60fps

2. **独立测试**
   ```typescript
   // 无需 React，纯单元测试
   const renderer = new FlowRenderer();
   renderer.setContainerWidth(800);
   const layout = renderer.calculateLayout(data);
   expect(layout.cols).toBe(66);
   ```

3. **可移植性**
   - 内核可被 Web Worker 使用
   - 可被原生应用复用（如 Electron 主进程）
   - 可被其他框架复用（Vue/Svelte）

4. **类型安全**
   - TypeScript 抽象类强制接口契约
   - 编译时检查子类实现

### 4.3 混合架构的劣势

1. **架构复杂**
   - 需要理解 OOP 和 FP 两种范式
   - 跨层通信较繁琐（ref 透传）

2. **状态同步**
   - React 状态与 OOP 状态需手动同步
   - 容易出 bug

3. **代码量**
   - 比纯 Hooks 多 30-40% 代码
   - 需要额外封装层

---

## 5. 性能对比

### 5.1 大数据量（20万）测试

| 操作 | Context + Hooks | 混合架构 | 差异 |
|------|----------------|---------|------|
| 首屏渲染 | ~60ms | ~50ms | 混合架构快 10ms |
| 缩放响应 | ~18ms | ~12ms | 混合架构快 6ms |
| 滚动 FPS | 60fps | 60fps | 无差异 |
| 内存占用 | ~160MB | ~150MB | 混合架构省 10MB |

**结论**: 性能差异不大（<10%），两种方案都能满足 60fps。

### 5.2 关键优化点

混合架构的优势主要在**快速缩放**场景：
- 纯 Hooks：Zoom 变化 -> React State 更新 -> Konva 渲染
- 混合架构：Zoom 变化 -> OOP 直接更新 Konva（跳过 React）

---

## 6. 实施建议

### 6.1 选择建议

**选择混合架构（本方案）如果：**
- 追求极致性能（渲染密集型应用）
- 未来可能脱离 React（如原生 Canvas、Web Worker）
- 团队熟悉 OOP，接受两层架构
- 需要独立的渲染内核复用

**选择 Context + Hooks（plan.md）如果：**
- 追求代码简洁和维护性
- 团队纯 React 背景
- 不需要脱离 React
- 性能要求不是极端苛刻

### 6.2 开发顺序

1. **Phase 1**: 设计抽象基类接口
2. **Phase 2**: 实现 BaseBitmapRenderer（共用逻辑）
3. **Phase 3**: 实现 MatrixRenderer（二维模式）
4. **Phase 4**: 实现 FlowRenderer（流模式，核心差异）
5. **Phase 5**: 实现 useBitmapEngine（Hooks 协调层）
6. **Phase 6**: 单元测试覆盖

### 6.3 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| OOP/Hooks 状态不一致 | 功能 bug | 统一状态管理，单向数据流 |
| 内存泄漏（OOP） | 页面卡顿 | 严格 cleanup，单元测试验证 |
| 架构复杂维护难 | 开发效率低 | 详细文档 + 代码审查 |

---

## 7. 结论

**混合架构是追求极致性能和可复用性的最佳选择**，但需权衡：

1. **优势**:
   - 极致性能（OOP 直接操作 Konva）
   - 独立可测试（纯单元测试）
   - 可脱离 React（Web Worker、原生应用）
   - 类型安全（TypeScript 抽象类）

2. **劣势**:
   - 架构复杂（两层抽象）
   - 代码量多（+30-40%）
   - 状态同步繁琐

3. **适用场景**:
   - 渲染密集型应用
   - 需要高性能的 Canvas 渲染
   - 未来可能跨平台复用

**最终建议**:
- 如果性能差异 <10% 可接受 -> 选 Context + Hooks（更简单）
- 如果需要极致性能/跨平台 -> 选混合架构（本方案）

---

## 附录

### A. 文件结构

```
src/webview/components/bitmap/
├── core/
│   └── renderers/
│       ├── BaseBitmapRenderer.ts   # 抽象基类
│       ├── MatrixRenderer.ts       # 二维模式
│       └── FlowRenderer.ts         # 流模式
├── hooks/
│   └── useBitmapEngine.ts          # Hooks 协调层
├── components/
│   ├── MatrixBitmap.tsx            # 二维模式组件
│   └── FlowBitmap.tsx              # 流模式组件
└── types.ts
```

### B. 关键接口

```typescript
// 抽象基类接口
abstract class BaseBitmapRenderer<T> {
  abstract calculateLayout(data: T[]): LayoutConfig;
  abstract getYAxisLabel(row: number): string;
  abstract getCellPosition(index: number): CellPosition;
  abstract getDataIndex(row: number, col: number): number;
  
  // 共用方法
  renderVisibleArea(...): void;
  setZoom(zoom: number): void;
  selectCell(row: number, col: number): SelectionInfo;
}

// Hooks 返回类型
interface UseBitmapEngineReturn {
  zoom: number;
  zoomIn: () => void;
  zoomOut: () => void;
  selectedCell: CellCoord | null;
  handleCellClick: (row: number, col: number) => SelectionInfo;
}
```

---

*文档版本: 1.0 | 创建日期: 2026-04-21 | 状态: 待确认*
