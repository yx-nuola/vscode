# Bitmap 可视化组件设计方案 - Context + Hooks 架构

## 文档信息

- **方案名称**: Context + Hooks 组合架构
- **推荐等级**: ★★★★★ (首选方案)
- **适用场景**: React 优先、团队熟悉 Hooks、追求简洁维护
- **创建日期**: 2026-04-21

---

## 1. 架构概述

### 1.1 设计目标

实现一个高性能、可复用的可视化组件，同时支持两种展示模式：

1. **规范二维模式 (Matrix)**: 固定 128×1024 网格，支持 X/Y 双向滚动
2. **流模式 (Flow)**: 动态列数，仅 Y 轴滚动，自动换行布局

### 1.2 核心设计原则

- **单一职责**: 渲染、布局、状态管理分离
- **性能优先**: 虚拟化渲染，大数据量（20万）下保持 60fps
- **可测试性**: 布局计算纯函数化，易于单元测试
- **React 风格**: 100% Hooks，无类组件，符合 React 官方推荐

### 1.3 架构分层

```
┌─────────────────────────────────────────────────────────┐
│ 组件层 (Components)                                      │
│  ├─ MatrixBitmap.tsx    (规范二维模式)                    │
│  └─ FlowBitmap.tsx      (流模式)                         │
├─────────────────────────────────────────────────────────┤
│ 上下文层 (Context)                                       │
│  ├─ KonvaContext.tsx    (Konva 实例管理)                │
│  └─ BitmapContext.tsx   (业务状态管理)                    │
├─────────────────────────────────────────────────────────┤
│ Hooks 层                                                │
│  ├─ useKonva.ts         (Konva 操作封装)                │
│  ├─ useZoom.ts          (缩放逻辑)                      │
│  ├─ useVirtualization.ts (虚拟化渲染)                   │
│  ├─ useMatrixLayout.ts  (规范二维布局)                  │
│  └─ useFlowLayout.ts    (流模式布局)                    │
├─────────────────────────────────────────────────────────┤
│ 渲染层 (Konva)                                          │
│  ├─ 高性能 Canvas 渲染                                   │
│  ├─ 对象池复用                                         │
│  └─ RAF 节流                                           │
└─────────────────────────────────────────────────────────┘
```

---

## 2. 核心模块设计

### 2.1 KonvaContext - Konva 实例管理

**职责**: 创建和管理 Konva Stage/Layer，提供渲染上下文

```typescript
// context/KonvaContext.tsx
interface KonvaContextType {
  stage: Konva.Stage | null;
  layer: Konva.Layer | null;
  cellPool: Map<string, Konva.Rect>;
  // 渲染方法
  renderCells: (cells: RenderCell[]) => void;
  clearCells: () => void;
  // 坐标转换
  getCellAt: (x: number, y: number) => CellCoord | null;
}

export const KonvaContext = createContext<KonvaContextType | null>(null);

export function KonvaProvider({ children, width, height }) {
  const stageRef = useRef<Konva.Stage>(null);
  const cellPool = useRef(new Map<string, Konva.Rect>());
  
  // 初始化 Konva Stage
  useEffect(() => {
    stageRef.current = new Konva.Stage({
      container: containerRef.current,
      width,
      height,
    });
    // ...
  }, []);
  
  return (
    <KonvaContext.Provider value={value}>
      {children}
    </KonvaContext.Provider>
  );
}
```

### 2.2 Layout Hooks - 布局计算

#### 2.2.1 useMatrixLayout (规范二维模式)

```typescript
// hooks/useMatrixLayout.ts
export function useMatrixLayout(data: CellData[]) {
  return useMemo(() => {
    const rows = 128;
    const cols = 1024;
    
    return {
      rows,
      cols,
      totalWidth: cols * cellSize,
      totalHeight: rows * cellSize,
      // 数据映射：根据 bl/wl 定位
      getCellPosition: (cell: CellData) => ({
        row: cell.bl,
        col: cell.wl,
      }),
      // Y轴刻度：0, 1, 2...
      getYAxisLabel: (row: number) => row.toString(),
    };
  }, [data]);
}
```

#### 2.2.2 useFlowLayout (流模式) - 核心差异点

```typescript
// hooks/useFlowLayout.ts
export function useFlowLayout(
  data: CellData[],
  containerWidth: number,
  cellSize: number
) {
  const [zoom, setZoom] = useState(1);
  
  return useMemo(() => {
    const actualCellSize = cellSize * zoom;
    // 根据容器宽度动态计算每行列数
    const cellsPerRow = Math.max(1, Math.floor(containerWidth / actualCellSize));
    const totalRows = Math.ceil(data.length / cellsPerRow);
    
    return {
      rows: totalRows,
      cols: cellsPerRow,
      totalWidth: cellsPerRow * actualCellSize,
      totalHeight: totalRows * actualCellSize,
      // 数据映射：根据数据索引计算行列
      getCellPosition: (index: number) => ({
        row: Math.floor(index / cellsPerRow),
        col: index % cellsPerRow,
      }),
      // Y轴刻度：显示数据起始索引 (0, 42, 84...)
      getYAxisLabel: (row: number) => (row * cellsPerRow).toString(),
      // 选中显示："42, 8" (起始索引, 列偏移)
      getSelectionDisplay: (row: number, col: number) => 
        `${row * cellsPerRow}, ${col}`,
      // 获取数据真实索引
      getDataIndex: (row: number, col: number) => row * cellsPerRow + col,
    };
  }, [data.length, containerWidth, cellSize, zoom]);
}
```

**关键差异**: 流模式的 `cellsPerRow` 随容器宽度和缩放动态变化

### 2.3 useVirtualization - 虚拟化渲染

```typescript
// hooks/useVirtualization.ts
export function useVirtualization({
  layout,
  viewportSize,
  scrollPos,
  overscan = 2,
}) {
  return useMemo(() => {
    const cp = cellSize * zoom; // cell pixel size
    const overscanPixels = Math.max(viewportSize.width, viewportSize.height) * overscan;
    
    // 计算可见区域
    const startRow = Math.max(0, Math.floor((scrollPos.y - overscanPixels) / cp));
    const endRow = Math.min(layout.rows, Math.ceil((scrollPos.y + viewportSize.height + overscanPixels) / cp));
    const startCol = Math.max(0, Math.floor((scrollPos.x - overscanPixels) / cp));
    const endCol = Math.min(layout.cols, Math.ceil((scrollPos.x + viewportSize.width + overscanPixels) / cp));
    
    return {
      startRow,
      endRow,
      startCol,
      endCol,
      visibleCellCount: (endRow - startRow) * (endCol - startCol),
    };
  }, [layout, viewportSize, scrollPos, zoom]);
}
```

### 2.4 useZoom - 缩放控制

```typescript
// hooks/useZoom.ts
export function useZoom(options: ZoomOptions) {
  const [zoom, setZoom] = useState(1);
  const zoomRef = useRef(zoom);
  
  const zoomIn = useCallback(() => {
    const next = Math.min(zoomRef.current + 0.1, MAX_ZOOM);
    setZoom(next);
    zoomRef.current = next;
  }, []);
  
  const zoomOut = useCallback(() => {
    const next = Math.max(zoomRef.current - 0.1, MIN_ZOOM);
    setZoom(next);
    zoomRef.current = next;
  }, []);
  
  const reset = useCallback(() => {
    setZoom(1);
    zoomRef.current = 1;
  }, []);
  
  return { zoom, zoomRef, zoomIn, zoomOut, reset };
}
```

---

## 3. 模式组件实现

### 3.1 MatrixBitmap (规范二维模式)

```typescript
// components/MatrixBitmap.tsx
export function MatrixBitmap({ data, ...props }) {
  const { zoom, zoomIn, zoomOut, reset } = useZoom();
  const layout = useMatrixLayout(data, zoom);
  const virtualization = useVirtualization({ layout, ... });
  const { renderCells } = useKonva();
  
  // 渲染可见区域
  useEffect(() => {
    const cells = [];
    for (let row = virtualization.startRow; row < virtualization.endRow; row++) {
      for (let col = virtualization.startCol; col < virtualization.endCol; col++) {
        const cell = getCellData(row, col);
        cells.push({
          x: col * cellSize * zoom,
          y: row * cellSize * zoom,
          width: cellSize * zoom,
          height: cellSize * zoom,
          color: getCellColor(cell),
        });
      }
    }
    renderCells(cells);
  }, [virtualization, zoom]);
  
  return (
    <KonvaProvider>
      <div className="matrix-bitmap">
        <Toolbar onZoomIn={zoomIn} onZoomOut={zoomOut} onReset={reset} zoom={zoom} />
        <CanvasContainer>
          {/* Konva Stage 挂载点 */}
        </CanvasContainer>
        <AxisY labels={layout.yAxisLabels} />
        <AxisX labels={layout.xAxisLabels} />
      </div>
    </KonvaProvider>
  );
}
```

### 3.2 FlowBitmap (流模式) - 核心差异

```typescript
// components/FlowBitmap.tsx
export function FlowBitmap({ data, ...props }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(800);
  
  // 监听容器宽度变化
  useEffect(() => {
    const observer = new ResizeObserver((entries) => {
      setContainerWidth(entries[0].contentRect.width);
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);
  
  const { zoom, zoomIn, zoomOut, reset } = useZoom();
  
  // 关键差异：根据容器宽度动态计算布局
  const layout = useFlowLayout(data, containerWidth, cellSize, zoom);
  const virtualization = useVirtualization({ 
    layout, 
    viewportSize,
    scrollPos,
  });
  
  // 选中处理：流模式特有
  const handleCellClick = useCallback((row: number, col: number) => {
    const dataIndex = layout.getDataIndex(row, col);
    const display = layout.getSelectionDisplay(row, col); // "42, 8"
    const cell = data[dataIndex];
    
    onSelect?.({
      mode: 'flow',
      row,
      col,
      dataIndex,
      display,
      cell,
    });
  }, [layout, data]);
  
  return (
    <KonvaProvider>
      <div className="flow-bitmap" ref={containerRef}>
        <Toolbar onZoomIn={zoomIn} onZoomOut={zoomOut} onReset={reset} zoom={zoom} />
        <CanvasContainer style={{ overflowX: 'hidden' }}> {/* 禁止横向滚动 */}
          {/* Konva Stage，宽度固定为容器宽度 */}
        </CanvasContainer>
        <AxisY 
          labels={generateYAxisLabels(layout.rows, layout.cellsPerRow)}
          // Y轴刻度：0, 42, 84...
        />
        {/* 无 X 轴 */}
      </div>
    </KonvaProvider>
  );
}
```

**关键差异点：**

| 特性 | MatrixBitmap | FlowBitmap |
|------|-------------|------------|
| 布局计算 | 固定 128×1024 | 动态：容器宽度 / 格子宽度 |
| X轴 | ✅ 显示 | ❌ 隐藏 |
| Y轴刻度 | 0, 1, 2... | 0, 42, 84... |
| 选中信息 | {row: 1, col: 5} | {display: "42, 8", index: 50} |
| 滚动方向 | X/Y 双向 | 仅 Y 轴 |

---

## 4. 性能优化策略

### 4.1 虚拟化渲染

- **仅渲染可见区域**: 20万数据只渲染 100-200 个格子
- **Overscan 预渲染**: 上下各多渲染 2 屏内容，避免白边
- **RAF 节流**: 使用 requestAnimationFrame 批量更新

### 4.2 对象池复用

```typescript
const cellPool = useRef<Map<string, Konva.Rect>>(new Map());

// 复用现有 Rect，避免重复创建
const renderCell = (key: string, x: number, y: number) => {
  let rect = cellPool.current.get(key);
  if (!rect) {
    rect = new Konva.Rect({ listening: false });
    cellPool.current.set(key, rect);
  }
  rect.x(x);
  rect.y(y);
  rect.visible(true);
  return rect;
};

// 隐藏不可见格子（而非销毁）
const hideInvisible = (visibleKeys: Set<string>) => {
  cellPool.current.forEach((rect, key) => {
    if (!visibleKeys.has(key)) rect.visible(false);
  });
};
```

### 4.3 缩放同步优化

```typescript
// 立即更新 ref，延迟更新 React 状态
const handleZoom = useCallback((delta: number) => {
  const next = clamp(zoomRef.current + delta, MIN_ZOOM, MAX_ZOOM);
  zoomRef.current = next; // 立即更新，无延迟
  
  // 同步更新 Konva
  stage.scaleX(next);
  stage.scaleY(next);
  
  // 延迟更新 React 状态（用于 UI 显示）
  setZoom(next);
}, []);
```

---

## 5. 单元测试策略

### 5.1 可测试的纯函数

```typescript
// __tests__/flowLayout.test.ts
describe('useFlowLayout', () => {
  it('calculates correct cells per row based on container width', () => {
    const layout = calculateFlowLayout({
      dataLength: 200000,
      containerWidth: 800,
      cellSize: 12,
      zoom: 1,
    });
    
    expect(layout.cellsPerRow).toBe(66); // floor(800/12)
    expect(layout.totalRows).toBe(3031); // ceil(200000/66)
    expect(layout.totalHeight).toBe(36372); // 3031 * 12
  });
  
  it('recalculates when zoom changes', () => {
    const layout = calculateFlowLayout({
      dataLength: 200000,
      containerWidth: 800,
      cellSize: 12,
      zoom: 1.2, // 放大
    });
    
    expect(layout.cellsPerRow).toBe(55); // floor(800/14.4)
    expect(layout.totalRows).toBe(3637); // ceil(200000/55)
  });
  
  it('maps data index to position correctly', () => {
    const layout = calculateFlowLayout({ cellsPerRow: 42 });
    
    expect(layout.getCellPosition(0)).toEqual({ row: 0, col: 0 });
    expect(layout.getCellPosition(41)).toEqual({ row: 0, col: 41 });
    expect(layout.getCellPosition(42)).toEqual({ row: 1, col: 0 });
    expect(layout.getCellPosition(50)).toEqual({ row: 1, col: 8 });
  });
  
  it('generates correct Y axis labels', () => {
    const layout = calculateFlowLayout({ cellsPerRow: 42 });
    
    expect(layout.getYAxisLabel(0)).toBe('0');
    expect(layout.getYAxisLabel(1)).toBe('42');
    expect(layout.getYAxisLabel(2)).toBe('84');
  });
});
```

### 5.2 组件测试

```typescript
// __tests__/FlowBitmap.test.tsx
describe('FlowBitmap', () => {
  it('renders without crashing', () => {
    render(<FlowBitmap data={mockData} />);
    expect(screen.getByTestId('flow-bitmap')).toBeInTheDocument();
  });
  
  it('handles cell selection with correct display format', () => {
    const onSelect = jest.fn();
    render(<FlowBitmap data={mockData} onSelect={onSelect} />);
    
    // 模拟点击第 50 个格子（row=1, col=8）
    fireEvent.click(screen.getByTestId('cell-50'));
    
    expect(onSelect).toHaveBeenCalledWith({
      mode: 'flow',
      row: 1,
      col: 8,
      dataIndex: 50,
      display: '42, 8',
      cell: mockData[50],
    });
  });
});
```

---

## 6. 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| ResizeObserver 兼容性问题 | 布局计算失效 | 使用 polyfill 或降级方案 |
| Konva 内存泄漏 | 页面卡顿 | useEffect cleanup 中销毁对象 |
| 快速缩放掉帧 | 交互卡顿 | RAF 节流 + zoomRef 同步 |
| 大数据量初始加载慢 | 白屏时间长 | 虚拟化 + loading 状态 |

---

## 7. 实施建议

### 7.1 开发顺序

1. **Phase 1**: 复用现有 BitmapEngine，抽离 KonvaContext
2. **Phase 2**: 实现 useMatrixLayout 和 MatrixBitmap
3. **Phase 3**: 实现 useFlowLayout 和 FlowBitmap（关键差异）
4. **Phase 4**: 单元测试覆盖
5. **Phase 5**: 性能优化（20万数据验证）

### 7.2 代码复用建议

- ✅ **复用**: BitmapEngineCore（虚拟化、缩放控制）
- ✅ **复用**: colorMap（颜色系统）
- ✅ **复用**: 选中事件处理逻辑
- 🆕 **新建**: useFlowLayout（动态列数计算）
- 🆕 **新建**: FlowBitmap 组件

---

## 8. 结论

**Context + Hooks 方案是推荐的首选方案**，理由：

1. ✅ **React 官方推荐**，符合现代 React 开发范式
2. ✅ **性能足够**：20万数据下依然 60fps（虚拟化 + 对象池）
3. ✅ **维护简单**：比混合架构少一层抽象
4. ✅ **单元测试友好**：布局计算纯函数化
5. ✅ **团队适应**：与现有 Hooks 代码风格一致

**适用场景**:
- React 优先的技术栈
- 团队熟悉 Hooks 模式
- 追求代码简洁和可维护性
- 不需要脱离 React 独立使用渲染内核

---

## 附录

### A. 关键接口定义

```typescript
// 统一选中信息接口
interface SelectionInfo {
  mode: 'matrix' | 'flow';
  row: number;
  col: number;
  dataIndex: number;
  display: string;
  cell: CellData;
}

// 布局配置
interface LayoutConfig {
  rows: number;
  cols: number;
  totalWidth: number;
  totalHeight: number;
  getCellPosition: (index: number) => { row: number; col: number };
  getYAxisLabel: (row: number) => string;
}
```

### B. 文件结构

```
src/webview/components/bitmap/
├── context/
│   ├── KonvaContext.tsx      # Konva 实例管理
│   └── BitmapContext.tsx     # 业务状态管理
├── hooks/
│   ├── useKonva.ts           # Konva 操作
│   ├── useZoom.ts            # 缩放控制
│   ├── useVirtualization.ts  # 虚拟化
│   ├── useMatrixLayout.ts    # 二维布局
│   └── useFlowLayout.ts      # 流布局
├── components/
│   ├── MatrixBitmap.tsx      # 二维模式
│   ├── FlowBitmap.tsx        # 流模式
│   └── Toolbar.tsx           # 缩放工具栏
└── types.ts                  # 类型定义
```


