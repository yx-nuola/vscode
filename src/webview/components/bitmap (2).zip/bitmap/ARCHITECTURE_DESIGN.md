# Bitmap Grid Architecture Design

## 一、设计目标

基于 think.md 的设计理念，构建高性能、可维护、可扩展的位图网格可视化系统。

### 核心需求
- 支持 128×1024 矩阵可视化（131,072 个格子）
- 虚拟滚动支持大规模数据集（100k+ 格子）
- 自定义滚动条和坐标轴（全 Konva 实现）
- 颜色映射和格子选择
- 表格-图形联动
- 多种数据导入格式（STDF、TXT 等）

### 设计原则（来自 think.md）
1. **模块化与分层架构** - 将复杂功能拆分为独立组件
2. **高内聚低耦合** - 每个文件有明确职责
3. **性能优化** - 分层渲染、节流/防抖、状态最小化
4. **事件驱动** - 响应式交互机制
5. **代码复用** - 基础类提供通用功能

## 二、目录结构

```
src/webview/components/bitmap/
├── core/                          # 核心架构
│   ├── interfaces/                # 接口定义
│   │   ├── IGridRenderer.ts       # 网格渲染接口
│   │   ├── IAxisRenderer.ts       # 坐标轴渲染接口
│   │   ├── IZoomable.ts           # 缩放控制接口
│   │   ├── IColorConfigurable.ts  # 颜色配置接口
│   │   ├── IScrollable.ts         # 滚动控制接口
│   │   └── ISelectable.ts         # 选择功能接口
│   ├── KonvaGridBase.ts           # 基础类（实现所有接口）
│   └── index.ts                   # 核心导出
│
├── layers/                        # 分层渲染（按 think.md 原则）
│   ├── ScrollbarLayer.ts          # 滚动条层
│   ├── AxisLayer.ts               # 坐标轴层
│   └── CellLayer.ts               # 格子层
│
├── draws/                         # 绘图逻辑（think.md: draws/）
│   ├── CellDrawer.ts              # 格子绘制
│   ├── AxisDrawer.ts              # 坐标轴绘制
│   ├── ScrollbarDrawer.ts         # 滚动条绘制
│   └── SelectionDrawer.ts         # 选择框绘制
│
├── tools/                         # 业务逻辑与状态管理（think.md: tools/）
│   ├── ScrollManager.ts           # 滚动管理器
│   ├── ZoomManager.ts             # 缩放管理器
│   ├── SelectionManager.ts        # 选择管理器
│   ├── ColorMapper.ts             # 颜色映射器
│   └── VirtualScrollManager.ts    # 虚拟滚动管理器
│
├── utils/                         # 工具函数（think.md: utils/）
│   ├── coordinate.ts              # 坐标转换
│   ├── formatting.ts              # 数值格式化
│   ├── event.ts                   # 事件封装
│   └── performance.ts             # 性能优化工具
│
├── renderers/                     # 具体渲染器实现
│   ├── SimpleBitmapGrid.ts        # 标准渲染器
│   └── PerformanceBitmapGrid.ts   # 高性能渲染器
│
├── components/                    # React 组件
│   ├── BitmapGrid.tsx             # React 包装器
│   └── BitmapGridDemo.tsx         # 演示组件
│
├── types.ts                       # 类型定义
├── index.tsx                      # 主组件
├── exports.ts                     # 统一导出
├── design.md                      # 本设计文档
├── think.md                       # 设计原则
└── index.md                       # 需求文档
```

## 三、分层架构设计

### 3.1 Konva 分层结构

```
Stage (固定视口大小)
├── Layer 1: 滚动条层（固定在底部层）
│   ├── 水平滚动条（滑轨 + 滑块）画布最下面显示
│   └── 垂直滚动条（滑轨 + 滑块）画布右侧显示
├── Layer 2: 坐标轴层（固定在中间层）
│   ├── X 轴（WL 刻度 + 标签） 画布最上面显示
│   └── Y 轴（BL 刻度 + 标签） 画布左侧显示
└── Layer 3: 格子层（可滚动）
    └── Group（随滚动位置移动） 由坐标轴和滚动条包围，中间区域展示格子绘制的网格图形
        └── 可见区域的格子（虚拟滚动）
```

### 3.2 分层渲染优势（think.md 原则）

✅ **避免全屏重绘**
- 仅更新变化的层（如滚动时只更新格子层）
- 滚动条层和坐标轴层保持固定

✅ **性能优化**
- 每层独立管理自己的 Konva 节点
- 减少不必要的重绘操作

✅ **职责分离**
- 每层负责特定的渲染内容
- 便于维护和扩展

## 四、模块职责划分

### 4.1 核心接口层（interfaces/）

#### IGridRenderer<T>
```typescript
interface IGridRenderer<T> {
    render(data: T[]): void;
    updateViewport(viewport: Viewport): void;
    clear(): void;
}
```
**职责**：定义网格渲染的基本接口

#### IAxisRenderer
```typescript
interface IAxisRenderer {
    renderXAxis(): void;
    renderYAxis(): void;
    updateAxisLabels(scrollX: number, scrollY: number): void;
}
```
**职责**：定义坐标轴渲染接口

#### IScrollable
```typescript
interface IScrollable {
    scrollTo(x: number, y: number): void;
    scrollBy(dx: number, dy: number): void;
    getScrollPosition(): { x: number; y: number };
}
```
**职责**：定义滚动控制接口

#### IZoomable
```typescript
interface IZoomable {
    zoomTo(scale: number): void;
    zoomBy(delta: number): void;
    getZoomLevel(): number;
}
```
**职责**：定义缩放控制接口

#### IColorConfigurable<T>
```typescript
interface IColorConfigurable<T> {
    setColorMapper(mapper: (value: T) => string): void;
    getColor(value: T): string;
}
```
**职责**：定义颜色配置接口

#### ISelectable<T>
```typescript
interface ISelectable<T> {
    selectCell(cell: T): void;
    deselectAll(): void;
    getSelectedCells(): T[];
}
```
**职责**：定义选择功能接口

### 4.2 分层渲染层（layers/）

#### ScrollbarLayer
**职责**：管理滚动条的渲染和交互
- 绘制水平滚动条（滑轨 + 滑块）
- 绘制垂直滚动条（滑轨 + 滑块）
- 处理滚动条拖拽事件
- 根据内容大小和视口大小计算滑块位置和大小

#### AxisLayer
**职责**：管理坐标轴的渲染和更新
- 绘制 X 轴（WL 刻度 + 标签）
- 绘制 Y 轴（BL 刻度 + 标签）
- 根据滚动位置更新坐标轴标签
- 格式化坐标显示（formatX, formatY）

#### CellLayer
**职责**：管理格子的渲染和虚拟滚动
- 使用 VirtualScrollManager 计算可见区域
- 使用 CellDrawer 绘制可见格子
- 使用对象池复用 Konva.Rect 对象
- 处理格子点击和悬停事件

### 4.3 绘图逻辑层（draws/）

#### CellDrawer
**职责**：负责格子绘制逻辑
- 创建和更新 Konva.Rect 对象
- 应用颜色映射
- 处理格子样式（边框、阴影等）
- 对象池管理（复用 Konva.Rect）

#### AxisDrawer
**职责**：负责坐标轴绘制逻辑
- 绘制坐标轴线
- 绘制刻度线
- 绘制刻度标签
- 格式化坐标显示

#### ScrollbarDrawer
**职责**：负责滚动条绘制逻辑
- 绘制滑轨
- 绘制滑块
- 绘制滚动条样式（颜色、圆角等）

#### SelectionDrawer
**职责**：负责选择框绘制逻辑
- 绘制选择框
- 绘制高亮格子
- 绘制选择指示器

### 4.4 业务逻辑层（tools/）

#### ScrollManager
**职责**：管理滚动状态和逻辑
- 维护滚动位置（scrollX, scrollY）
- 计算滚动范围
- 处理滚动事件（wheel, drag）
- 边界控制（防止超出范围）
- 节流/防抖优化

#### ZoomManager
**职责**：管理缩放状态和逻辑
- 维护缩放级别（zoomLevel）
- 处理缩放事件（wheel, pinch）
- 计算缩放后的坐标
- 边界控制（防止无效缩放）

#### SelectionManager
**职责**：管理选择状态和逻辑
- 维护选中的格子列表
- 处理选择事件（click, drag-select）
- 支持多选和单选
- 触发选择回调

#### ColorMapper
**职责**：管理颜色映射逻辑
- 定义颜色映射规则
- 根据值返回颜色
- 支持自定义颜色映射
- 支持渐变色映射

#### VirtualScrollManager
**职责**：管理虚拟滚动逻辑
- 计算可见区域
- 计算需要渲染的格子范围
- Overscan 优化（预渲染边缘格子）
- 滚动位置同步

### 4.5 工具函数层（utils/）

#### coordinate.ts
**职责**：坐标转换工具
- 数据坐标 → 屏幕坐标
- 屏幕坐标 → 数据坐标
- 滚动位置计算
- 缩放坐标计算

#### formatting.ts
**职责**：数值格式化工具
- WL 坐标格式化
- BL 坐标格式化
- 数值精度控制
- 单位转换

#### event.ts
**职责**：事件封装工具
- 节流函数
- 防抖函数
- 事件合成
- 事件委托

#### performance.ts
**职责**：性能优化工具
- RAF 调度
- 对象池管理
- 性能监控
- 内存优化

### 4.6 渲染器实现层（renderers/）

#### SimpleBitmapGrid
**职责**：标准渲染器实现
- 继承 KonvaGridBase
- 实现所有接口
- 适用于一般场景

#### PerformanceBitmapGrid
**职责**：高性能渲染器实现
- 继承 KonvaGridBase
- 实现所有接口
- 包含性能优化（对象池、RAF 调度等）
- 适用于大规模数据集

### 4.7 React 组件层（components/）

#### BitmapGrid.tsx
**职责**：React 包装器
- 封装 Konva Stage
- 管理 React 状态
- 处理 React 事件
- 提供 React API

#### BitmapGridDemo.tsx
**职责**：演示组件
- 展示完整用法
- 包含示例数据
- 展示所有功能

## 五、数据流设计

### 5.1 初始化流程

```
1. React 组件挂载
   ↓
2. 创建 Konva Stage
   ↓
3. 创建 3 个 Layer（ScrollbarLayer, AxisLayer, CellLayer）
   ↓
4. 初始化各个 Manager（ScrollManager, ZoomManager, SelectionManager, ColorMapper, VirtualScrollManager）
   ↓
5. 初始化各个 Drawer（CellDrawer, AxisDrawer, ScrollbarDrawer, SelectionDrawer）
   ↓
6. 注册事件监听器
   ↓
7. 首次渲染
```

### 5.2 滚动流程

```
1. 用户触发滚动事件（wheel 或拖拽滚动条）
   ↓
2. ScrollManager 处理滚动事件
   ↓
3. ScrollManager 更新滚动位置（scrollX, scrollY）
   ↓
4. ScrollManager 触发滚动回调
   ↓
5. VirtualScrollManager 计算新的可见区域
   ↓
6. CellLayer 更新可见格子
   ↓
7. AxisLayer 更新坐标轴标签
   ↓
8. ScrollbarLayer 更新滑块位置
   ↓
9. Konva 重绘（仅更新变化的层）
```

### 5.3 缩放流程

```
1. 用户触发缩放事件（wheel 或 pinch）
   ↓
2. ZoomManager 处理缩放事件
   ↓
3. ZoomManager 更新缩放级别（zoomLevel）
   ↓
4. ZoomManager 触发缩放回调
   ↓
5. CellLayer 更新格子大小
   ↓
6. AxisLayer 更新坐标轴刻度
   ↓
7. ScrollbarLayer 更新滑块大小
   ↓
8. Konva 重绘（仅更新变化的层）
```

### 5.4 选择流程

```
1. 用户触发选择事件（click 或 drag-select）
   ↓
2. SelectionManager 处理选择事件
   ↓
3. SelectionManager 更新选中格子列表
   ↓
4. SelectionManager 触发选择回调
   ↓
5. SelectionDrawer 绘制选择框
   ↓
6. CellLayer 高亮选中的格子
   ↓
7. Konva 重绘（仅更新变化的层）
```

## 六、性能优化策略

### 6.1 虚拟滚动

**原理**：只渲染可见区域的格子，不渲染所有数据

**实现**：
- VirtualScrollManager 计算可见区域
- CellLayer 只渲染可见格子
- Overscan 优化（预渲染边缘格子）

**收益**：
- 100k+ 格子只渲染 ~1000 个可见格子
- 大幅减少 DOM 节点数量
- 提升渲染性能

### 6.2 对象池

**原理**：复用 Konva.Rect 对象，避免频繁创建和销毁

**实现**：
- CellDrawer 维护对象池
- 滚动时复用对象池中的对象
- 只更新对象的属性（x, y, fill）

**收益**：
- 减少垃圾回收压力
- 提升滚动性能
- 降低内存占用

### 6.3 RAF 调度

**原理**：使用 requestAnimationFrame 调度渲染

**实现**：
- 使用 RAF 调度渲染函数
- 避免高频事件导致的性能问题
- 合并多次渲染请求

**收益**：
- 平滑的滚动和缩放
- 避免掉帧
- 提升用户体验

### 6.4 分层渲染

**原理**：只更新变化的层，不重绘整个 Stage

**实现**：
- 每层独立管理自己的 Konva 节点
- 滚动时只更新格子层
- 滚动条层和坐标轴层保持固定

**收益**：
- 减少不必要的重绘
- 提升渲染性能
- 降低 CPU 占用

### 6.5 节流/防抖

**原理**：限制高频事件的触发频率

**实现**：
- wheel 事件使用节流
- mousemove 事件使用防抖
- resize 事件使用防抖

**收益**：
- 减少事件处理次数
- 提升性能
- 避免卡顿

### 6.6 Konva 性能优化

**配置**：
```typescript
Konva.Rect({
    perfectDrawEnabled: false,  // 禁用完美绘制
    shadowEnabled: false,       // 禁用阴影
    listening: false,           // 禁用事件监听（格子不需要）
});
```

**收益**：
- 提升渲染性能
- 降低内存占用
- 减少事件处理开销

## 七、事件处理设计

### 7.1 事件类型

| 事件类型 | 处理器 | 说明 |
|---------|--------|------|
| wheel | ScrollManager, ZoomManager | 滚动和缩放 |
| mousedown | SelectionManager | 开始选择 |
| mousemove | SelectionManager | 拖拽选择 |
| mouseup | SelectionManager | 结束选择 |
| click | SelectionManager | 单击选择 |
| drag | ScrollManager | 拖拽滚动 |
| resize | VirtualScrollManager | 窗口大小变化 |

### 7.2 事件流

```
用户交互
   ↓
Konva Stage 捕获事件
   ↓
事件分发到对应的 Layer
   ↓
Layer 转发到对应的 Manager
   ↓
Manager 处理业务逻辑
   ↓
Manager 更新状态
   ↓
Manager 触发回调
   ↓
Layer 更新渲染
   ↓
Konva 重绘
```

### 7.3 事件优化

- **事件委托**：在 Stage 层统一处理事件，避免在每个格子上注册事件
- **节流/防抖**：限制高频事件的触发频率
- **事件合成**：将多个事件合并为一个事件处理

## 八、状态管理设计

### 8.1 状态类型

```typescript
interface GridState {
    // 滚动状态
    scrollX: number;
    scrollY: number;
    maxScrollX: number;
    maxScrollY: number;

    // 缩放状态
    zoomLevel: number;
    minZoomLevel: number;
    maxZoomLevel: number;

    // 选择状态
    selectedCells: CellData[];
    selectionMode: 'single' | 'multiple';

    // 颜色状态
    colorMapper: (value: any) => string;

    // 视口状态
    viewportWidth: number;
    viewportHeight: number;
    contentWidth: number;
    contentHeight: number;
}
```

### 8.2 状态更新流程

```
1. Manager 更新内部状态
   ↓
2. Manager 触发状态变更回调
   ↓
3. React 组件更新 React 状态
   ↓
4. React 组件重新渲染
   ↓
5. Konva 更新渲染
```

### 8.3 状态同步

- **单向数据流**：状态从 Manager 流向 React 组件，再流向 Konva
- **状态最小化**：只存储必要的状态，避免冗余
- **状态缓存**：缓存计算结果（如视口范围、坐标映射）

## 九、扩展性设计

### 9.1 新增绘图类型

**步骤**：
1. 在 `draws/` 目录下创建新的 Drawer 类
2. 实现必要的接口（如 IDrawable）
3. 在对应的 Layer 中注册新的 Drawer
4. 在 KonvaGridBase 中添加新的 Layer

**示例**：新增标注绘制
```typescript
// draws/AnnotationDrawer.ts
class AnnotationDrawer {
    draw(annotations: Annotation[]): void {
        // 绘制标注
    }
}

// 在 AxisLayer 中使用
class AxisLayer {
    private annotationDrawer = new AnnotationDrawer();

    render() {
        this.annotationDrawer.draw(this.annotations);
    }
}
```

### 9.2 新增功能

**步骤**：
1. 在 `tools/` 目录下创建新的 Manager 类
2. 实现必要的接口
3. 在 KonvaGridBase 中注册新的 Manager
4. 在 React 组件中暴露新的 API

**示例**：新增框选功能
```typescript
// tools/BoxSelectionManager.ts
class BoxSelectionManager {
    selectBox(rect: Rect): void {
        // 框选逻辑
    }
}

// 在 KonvaGridBase 中使用
class KonvaGridBase {
    private boxSelectionManager = new BoxSelectionManager();

    handleMouseDown(e: Konva.KonvaEventObject<MouseEvent>) {
        this.boxSelectionManager.startSelection(e);
    }
}
```

### 9.3 替换渲染引擎

**步骤**：
1. 创建新的渲染引擎（如 WebGL）
2. 实现相同的接口（IGridRenderer, IAxisRenderer 等）
3. 在 KonvaGridBase 中替换渲染引擎

**示例**：使用 WebGL 替换 Canvas
```typescript
// renderers/WebGLBitmapGrid.ts
class WebGLBitmapGrid implements IGridRenderer<CellData> {
    render(data: CellData[]): void {
        // WebGL 渲染逻辑
    }
}

// 在 React 组件中使用
<BitmapGrid renderer={WebGLBitmapGrid} />
```

## 十、测试策略

### 10.1 单元测试

**测试范围**：
- 工具函数（utils/）
- Manager 逻辑（tools/）
- Drawer 逻辑（draws/）

**测试工具**：
- Jest
- React Testing Library

### 10.2 集成测试

**测试范围**：
- Layer 渲染
- 事件处理
- 状态管理

**测试工具**：
- Jest
- React Testing Library
- Konva Testing Utils

### 10.3 性能测试

**测试范围**：
- 虚拟滚动性能
- 对象池性能
- 渲染性能

**测试工具**：
- Chrome DevTools
- Lighthouse
- Performance API

## 十一、总结

### 11.1 设计优势

✅ **模块化**：清晰的目录结构，每个文件有明确职责
✅ **高性能**：虚拟滚动、对象池、RAF 调度、分层渲染
✅ **可维护**：高内聚低耦合，易于理解和修改
✅ **可扩展**：易于添加新功能和替换组件
✅ **响应式**：事件驱动的响应机制

### 11.2 适用场景

🎯 大规模波形分析
🎯 EDA 工具
🎯 金融行情图
🎯 科学可视化
🎯 高性能图形应用

### 11.3 下一步

1. 实现新的架构
2. 编写单元测试
3. 性能优化和调优
4. 文档完善
